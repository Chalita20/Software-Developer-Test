let express = require('express');
const { route } = require('express/lib/application');
let router = express.Router();
let dbCon = require('../lib/db');

router.get('/', (req, res, next) => {
    dbCon.query('SELECT * FROM people ORDER BY id asc', (err, rows) => {
        if (err) {
            req.flash('error', err);
            res.render('people', { data: '' });
        } else {
            res.render('people', { data: rows });
        }
    })
})

//display add people page
router.get('/add', (req, res, next) => {
    res.render('people/add', {
        name: '',
        address: '',
        gerder: '',
        age: ''
    })
})

router.post('/add', (req, res, next) => {
    let name = req.body.name;
    let address = req.body.address;
    let gerder = req.body.gerder;
    let age = req.body.age;
    let errors = false;

    if (name.length === 0 || address.length === 0) {
        errors = true;

        req.flash('error', 'Please enter your information');

        res.render('people/add', {
            name: name,
            address: address,
            gerder: gerder,
            age: age
        })
    }

    if (!errors) {
        let form_data = {
            name: name,
            address: address,
            gerder: gerder,
            age: age
        }

        dbCon.query('INSERT INTO people SET ?', form_data, (err, result) => {
            if (err) {
                req.flash('error', err)

                res.render('people/add', {
                    name: form_data.name,
                    address: form_data.address,
                    gerder: form_data.gerder,
                    age: form_data.age
                })
            } else {
               req.flash('success', 'Your Information successfully added!'); 
               res.redirect('/people')
            }
        })
    }

})

router.get('/edit/(:id)', (req, res, next) => {
    let id = req.params.id;

    dbCon.query('SELECT * FROM people WHERE id = ' + id, (err, rows, fields) =>{
        if (rows.length <= 0) {
            req.flash('error', 'Information not found with id = ' + id)
            res.redirect('/people');
        } else {
            res.render('people/edit', {
                title: 'Edit people',
                id: rows[0].id,
                name: rows[0].name,
                address: rows[0].address,
                gerder: rows[0].gerder,
                age: rows[0].age
            })
        }
    });
})

// update people
router.post('/update/:id', (req, res, next) => {
    let id = req.params.id;
    let name = req.body.name;
    let address = req.body.address;
    let gerder = req.body.gerder;
    let age = req.body.age;
    let errors = false;

    if (name.length === 0 || address.length === 0 || gerder.length === 0 || age.length === 0) {
        errors = true;
        req.flash('error', 'Please enter your information');
        res.render('people/edit', {
           id: req.params.id,
           name: name,
           address: address,
           gerder: gerder,
           age: age 
        })
    }

    // if no error
    if (!errors) {
        let form_data = {
            name: name,
            address: address,
            gerder: gerder,
            age: age
        }
        // update query
        dbCon.query("UPDATE people SET ? WHERE id = " + id, form_data, (err, result) => {
            if (err) {
                req.flash('error', err);
                res.render('people/edit', {
                    id: req.params.id,
                    name: form_data.name,
                    address: form_data.address,
                    gerder: form_data.gerder,
                    age: form_data.age
                })
            } else {
                req.flash('success', 'Your Information successfully updated');
                res.redirect('/people')
            }
        })
    }
})

//delete people
router.get('/delete/(:id)', (req, res, next) => {
    let id = req.params.id;

    dbCon.query('DELETE FROM people WHERE id = ' + id, (err, result) => {
        if (err) {
            req.flash('error', err),
            res.redirect('/people');
        } else {
            req.flash('success', 'Your Information successfully deleted! ID = ' + id);
            res.redirect('/people');
        }
    })
})

module.exports = router;